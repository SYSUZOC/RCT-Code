import torch
import torchvision
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_curve, auc
import pandas as pd 
import os 

# Hyperparameters
learning_rate = 0.01
batch_size = 32
num_epochs = 10
num_classes = 3 # normal, cataract, surgery
test_ratio = 0.1 
val_ratio = 0.1 
test_set_path = "C:\\Users\\18359\\Desktop\\test set\\test set" 
excel_path = "C:\\Users\\18359\\Desktop\\test_result.xlsx" 


transform = transforms.Compose(
    [transforms.Resize(256), # Resize the images to 256 x 256 pixels
     transforms.RandomCrop(224), # Randomly crop the images to 224 x 224 pixels
     transforms.RandomHorizontalFlip(), # Randomly flip the images horizontally
     transforms.RandomRotation(10), # Randomly rotate the images by 10 degrees
     transforms.ToTensor(), # Convert the images to tensors
     transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)) # Normalize the images using the mean and std of ImageNet dataset
    ])

# Load the dataset from the folder
dataset = torchvision.datasets.ImageFolder(root="C:\\Users\\18359\\Desktop\\tester01(1)\\tester01", transform=transform)

# Split the dataset into train, val and test sets
test_size = int(test_ratio * len(dataset)) # Use test_ratio of the data for testing
val_size = int(val_ratio * (len(dataset) - test_size)) # Use val_ratio of the rest for validation
train_size = len(dataset) - test_size - val_size # Use the rest for training
train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(dataset, [train_size, val_size, test_size])

# Create data loaders for train, val and test sets
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


# Load a pre-trained ResNet-50 model
model = torchvision.models.resnet50(pretrained=True)

# Modify the last layer to match the number of classes
model.fc = torch.nn.Linear(model.fc.in_features, num_classes)



# Define the loss function
criterion = torch.nn.CrossEntropyLoss()

# Define the optimizer
optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate, momentum=0.9)


# Move the model to GPU if available
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

# Train and test the model
best_acc = 0.0 # Initialize the best validation accuracy
best_model = None # Initialize the best model state
for epoch in range(num_epochs):
    # Train the model on the train set
    model.train() # Set the model to training mode
    train_loss = 0.0 # Initialize the train loss
    for i, (images, labels) in enumerate(train_loader):
        # Move the images and labels to GPU if available
        images = images.to(device)
        labels = labels.to(device)

        # Forward pass
        outputs = model(images) # Get the outputs of the model
        loss = criterion(outputs, labels) # Compute the loss

        # Backward and optimize
        optimizer.zero_grad() # Zero the parameter gradients
        loss.backward() # Backpropagate the loss
        optimizer.step() # Update the model parameters

        # Print statistics
        train_loss += loss.item() # Accumulate the train loss
        if (i + 1) % 10 == 0: # Print every 10 batches
            print(f'Epoch {epoch + 1}, Batch {i + 1}, Loss: {train_loss / 10:.4f}')
            train_loss = 0.0 # Reset the train loss

    # Validate the model on the val set
    model.eval() # Set the model to evaluation mode
    correct = 0 # Initialize the number of correct predictions
    total = 0 # Initialize the total number of predictions
    with torch.no_grad(): # Disable gradient computation
        for images, labels in val_loader:
            # Move the images and labels to GPU if available
            images = images.to(device)
            labels = labels.to(device)

            # Forward pass
            outputs = model(images) # Get the outputs of the model
            _, predicted = torch.max(outputs, 1) # Get the predicted class

            # Compute accuracy
            total += labels.size(0) # Update the total number of predictions
            correct += (predicted == labels).sum().item() # Update the number of correct predictions

    # Print accuracy
    acc = 100 * correct / total # Calculate the validation accuracy
    print(f'Epoch {epoch + 1}, Validation Accuracy: {acc:.2f}%')

    # Save the best model
    if acc > best_acc: # If the validation accuracy is better than the best accuracy
        best_acc = acc # Update the best accuracy
        best_model = model.state_dict() # Save the best model state

torch.save(best_model, "C:\\Users\\18359\\Desktop\\best_model.pth") # Save the best model state to a file
torch.save(best_model, "best_model.pth") # Save the best model state to a file

# Test the model on the test set
model.load_state_dict(best_model) # Load the best model state
model.eval() # Set the model to evaluation mode
correct = 0 # Initialize the number of correct predictions
total = 0 # Initialize the total number of predictions
with torch.no_grad(): # Disable gradient computation
    for images, labels in test_loader:
        # Move the images and labels to GPU if available
        images = images.to(device)
        labels = labels.to(device)

        # Forward pass
        outputs = model(images) # Get the outputs of the model
        _, predicted = torch.max(outputs, 1) # Get the predicted class

        # Compute accuracy
        total += labels.size(0) # Update the total number of predictions
        correct += (predicted == labels).sum().item() # Update the number of correct predictions

# Print accuracy
print(f'Test Accuracy: {100 * correct / total:.2f}%')


#%%
from PIL import Image # 导入Image类


# Test the model on another test set and generate excel file
model.eval() # Set the model to evaluation mode
correct = 0 # Initialize the number of correct predictions
total = 0 # Initialize the total number of predictions
y_true = [] # Initialize the list of true labels
y_pred = [] # Initialize the list of predicted labels
y_score = [] # Initialize the list of predicted scores
image_names = [] # Initialize the list of image names
with torch.no_grad(): # Disable gradient computation
    for image_name in os.listdir(test_set_path): # Loop over the image names in the test set path
        image_path = os.path.join(test_set_path, image_name) # Get the full image path
        image = Image.open(image_path) # Open the image using PIL library
        image = transform(image) # Apply the same transform as the training data
        image = image.unsqueeze(0) # Add a batch dimension
        image = image.to(device) # Move the image to GPU if available

        # Forward pass
        outputs = model(image) # Get the outputs of the model
        _, predicted = torch.max(outputs, 1) # Get the predicted class
        scores = torch.nn.functional.softmax(outputs, dim=1) # Get the predicted scores

        # Append to lists
        image_names.append(image_name) # Append image name to list
        y_pred.append(predicted.item()) # Append predicted label to list
        y_score.append(scores[0].cpu().numpy()) # Append predicted scores to list
#%%
# Generate excel file
df = pd.DataFrame() # Create an empty data frame
df["image_name"] = image_names # Add a column for image names
df["predict"] = y_pred # Add a column for predicted labels
df["predict"] = df["predict"].map({1: "Normal", 0: "Cataract", 2: "Surgery"}) # Map the numeric labels to string labels
df["predict_proba_Normal"] = [score[1] for score in y_score] # Add a column for predicted probabilities of Normal
df["predict_proba_Cataract"] = [score[0] for score in y_score] # Add a column for predicted probabilities of Cataract
df["predict_proba_Surgery"] = [score[2] for score in y_score] # Add a column for predicted probabilities of Surgery
df.to_excel(excel_path, index=False) # Save the data frame to excel file


# Print message
print(f"Test result saved to {excel_path}") # Print the message