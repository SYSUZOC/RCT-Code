import numpy as np
import os
import tensorflow as tf
from sklearn.metrics import classification_report
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 设置可见的 GPU 设备
os.environ["CUDA_VISIBLE_DEVICES"] = "1"


base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
model = Sequential()
model.add(base_model)
model.add(GlobalAveragePooling2D())
model.add(Dense(3, activation='softmax'))


custom_optimizer = Adam(learning_rate=0.0001)  # 调整学习率至适当水平


model.compile(optimizer=custom_optimizer, loss='categorical_crossentropy', metrics=['accuracy'])


train_datagen = ImageDataGenerator(rescale=1./255,
                                   shear_range=0.2,
                                   zoom_range=0.2,
                                   horizontal_flip=True)

test_datagen = ImageDataGenerator(rescale=1./255)


train_generator = train_datagen.flow_from_directory('train', target_size=(224, 224), batch_size=64, class_mode='categorical')

test_generator = test_datagen.flow_from_directory('validation', target_size=(224, 224), batch_size=64, class_mode='categorical')


with tf.device('/device:GPU:1'):
    model.fit(train_generator, epochs=50, validation_data=test_generator)



model.save('resnet50_model.h5')



y_true = test_generator.classes
y_pred = np.argmax(model.predict(test_generator), axis=1)
target_names = list(test_generator.class_indices.keys())

report = classification_report(y_true, y_pred, target_names=target_names)
print(report)
