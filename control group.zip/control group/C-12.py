import os
import cv2
import numpy as np
import random
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# 数据集路径
DATASET_PATH = 'D:/tester01/'

# 图片尺寸
IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS = 128, 128, 3

# 类别映射
categories = ['normal', 'cataract', 'surgery']
label_map = {category: idx for idx, category in enumerate(categories)}

def load_and_preprocess_image(image_path):
    image = cv2.imread(image_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image, (IMG_HEIGHT, IMG_WIDTH))
    return image / 255.0

def prepare_dataset(image_paths):
    num_images = len(image_paths)
    X = np.ndarray((num_images, IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS), dtype=np.float32)
    y = np.zeros((num_images,), dtype=int)
    for idx, image_path in enumerate(image_paths):
        X[idx] = load_and_preprocess_image(image_path)
        for category, label in label_map.items():
            if category in image_path:
                y[idx] = label
                break
        if idx % 1000 == 0:
            print(f'已处理 {idx} / {num_images} 张图像')
    return X, to_categorical(y, num_classes=len(categories))

# 获取所有图像文件路径
all_image_files = [os.path.join(dirpath, file) for dirpath, dirnames, files in os.walk(DATASET_PATH) for file in files if os.path.splitext(file)[1].lower() in ['.png', '.jpg', '.jpeg']]
random.shuffle(all_image_files)

# 准备数据和标签
images, labels = prepare_dataset(all_image_files)

# 划分数据集
X_train, X_temp, y_train, y_temp = train_test_split(images, labels, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)


# 构建CNN模型
def create_cnn_model():
    model = Sequential()
    
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS)))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    
    model.add(Conv2D(128, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    
    model.add(Flatten())
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(len(categories), activation='softmax'))
    
    model.compile(optimizer=Adam(learning_rate=0.001), loss='categorical_crossentropy', metrics=['accuracy'])
    
    return model

model = create_cnn_model()

# 训练模型
model.fit(X_train, y_train, batch_size=32, epochs=10, validation_data=(X_val, y_val))

# 模型评估
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=1)
print(f'损失: {test_loss}, 准确率: {test_acc}')

model.save('cnn_model.h5')
