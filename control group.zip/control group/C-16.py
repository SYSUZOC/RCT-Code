
import os
import shutil
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from sklearn.model_selection import train_test_split
from glob import glob

dataset_path = 'C:/eye/cataract/tester01'  
train_path = os.path.join(dataset_path, 'train')
val_path = os.path.join(dataset_path, 'val')
test_path = os.path.join(dataset_path, 'test')

for set_name in ['train', 'val', 'test']:
    for category in ['normal', 'cataract', 'surgery']:
        os.makedirs(os.path.join(dataset_path, set_name, category), exist_ok=True)

def split_data(source, train_dir, val_dir, test_dir, train_size=0.7, val_size=0.2):
    test_size = 1 - train_size - val_size
    for category in ['normal', 'cataract', 'surgery']:
        source_path = os.path.join(source, category)
        files = os.listdir(source_path)
        train_files, test_files = train_test_split(files, test_size=1-train_size, random_state=42)
        val_files, test_files = train_test_split(test_files, test_size=test_size/(1-train_size), random_state=42)

        for file in train_files:
            shutil.copy(os.path.join(source_path, file), os.path.join(train_dir, category, file))
        for file in val_files:
            shutil.copy(os.path.join(source_path, file), os.path.join(val_dir, category, file))
        for file in test_files:
            shutil.copy(os.path.join(source_path, file), os.path.join(test_dir, category, file))

split_data(dataset_path, train_path, val_path, test_path)

train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True)

val_datagen = ImageDataGenerator(rescale=1./255)
test_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_directory(
    train_path,
    target_size=(150, 150),
    batch_size=32,
    class_mode='categorical')

validation_generator = val_datagen.flow_from_directory(
    val_path,
    target_size=(150, 150),
    batch_size=32,
    class_mode='categorical')

test_generator = test_datagen.flow_from_directory(
    test_path,
    target_size=(150, 150),
    batch_size=32,
    class_mode='categorical',
    shuffle=False)

model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(150, 150, 3)),
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Flatten(),
    Dense(512, activation='relu'),
    Dropout(0.5),
    Dense(3, activation='softmax')
])

model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    epochs=10,  
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // validation_generator.batch_size)

test_loss, test_acc = model.evaluate(test_generator)
print(f'Test accuracy: {test_acc}, Test loss: {test_loss}')

model.save('cataract_identification.h5')
