import os
import torch
import torchvision
from torchvision import models, transforms
from PIL import Image

device = torch.device("cuda:0" if torch.cuda.is_available() else 'cpu')
n_classes = 3  # 几种分类的
pretrain = True  # 是否使用预训练参数

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

model = models.resnet18(pretrained=pretrain)
model.fc = torch.nn.Linear(in_features=512, out_features=n_classes, bias=True)
model = model.to(device)

model_path = 'resNet50.pth'  # 训练好的模型路径
model.load_state_dict(torch.load(model_path))
model.eval()

input_folder = r'D:\pythonProject\白内障\tester01\valid\surgery' 

image_files = [f for f in os.listdir(input_folder) if f.endswith('.jpg') or f.endswith('.jpeg')]

for image_file in image_files:
    image_path = os.path.join(input_folder, image_file)
    image = Image.open(image_path)
    image_tensor = transform(image).unsqueeze_(0).to(device)

    with torch.no_grad():
        output = model(image_tensor)
        _, predicted = torch.max(output, 1)

    predicted_class = predicted.item()
    classes = ['白内障', '正常', '术后']
    predicted_label = classes[predicted_class]

    print(f'图片：{image_file}，预测结果：{predicted_label}')
