import os
import shutil
import random

dataset_path = "./tester01/surgery"
dataset_path1 = "./tester01"
train_ratio, val_ratio, test_ratio = 0.6, 0.2, 0.2
data1 = "/surgery"

image_list = os.listdir(dataset_path)
image_list = [x for x in image_list if x.endswith(".jpeg")]  

random.shuffle(image_list)
total_num = len(image_list)
train_num = int(total_num * train_ratio)
val_num = int(total_num * val_ratio)

os.makedirs(dataset_path1 + "/train" + data1, exist_ok=True)
os.makedirs(dataset_path1 + "/val" + data1, exist_ok=True)
os.makedirs(dataset_path1 + "/test" + data1, exist_ok=True)

for i, image in enumerate(image_list):
    if i < train_num:
        target_folder = "train"
    elif i < train_num + val_num:
        target_folder = "val"
    else:
        target_folder = "test"

    dst_filename = f"{target_folder}_{image}"
    dst = os.path.join(dataset_path1, target_folder + data1, dst_filename)

    src = os.path.join(dataset_path, image)
    if not os.path.exists(dst):  
        shutil.copyfile(src, dst)

print("图片复制完成！")
