import tkinter as tk
from tkinter import filedialog
import torch
from torchvision import models, transforms
from PIL import Image, ImageTk

class ImageClassifierApp:
    def __init__(self, window):
        self.window = window
        self.window.title("白内障自动识别检测系统")
        # 设置窗口图标
        window.iconbitmap("icon.ico")
        self.label_image = tk.Label(window, bd=5, relief="ridge")
        self.label_image.grid(row=0, column=0, padx=20, pady=20, rowspan=4)

        # 加载替代图片
        placeholder_image = Image.open('test.png')
        self.image_size = (512, 512)
        placeholder_image = placeholder_image.resize(self.image_size)
        placeholder_photo = ImageTk.PhotoImage(placeholder_image)
        self.label_image.configure(image=placeholder_photo)
        self.label_image.image = placeholder_photo

        self.btn_upload = tk.Button(window, text="上传", width=10, command=self.upload_image)
        self.btn_upload.grid(row=0, column=1, padx=10, pady=10)

        self.btn_predict = tk.Button(window, text="预测", width=10, command=self.predict_image)
        self.btn_predict.grid(row=1, column=1, padx=10, pady=10)

        self.label_result = tk.Label(window, text="预测结果：", font=("Arial", 16))
        self.label_result.grid(row=2, column=1, padx=10, pady=10, sticky="w")

        self.label_path = tk.Label(window, text="图片路径：", font=("Arial", 10))
        self.label_path.grid(row=3, column=1, padx=10, pady=10, sticky="w")

        self.image_size = (512, 512)

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.n_classes = 3
        self.pretrain = True

        self.transform = transforms.Compose([
            transforms.Resize(self.image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

        self.model = models.resnet18(pretrained=self.pretrain)
        self.model.fc = torch.nn.Linear(in_features=512, out_features=self.n_classes, bias=True)
        self.model = self.model.to(self.device)

        self.model_path = 'resNet50.pth'
        self.model.load_state_dict(torch.load(self.model_path))
        self.model.eval()

    def upload_image(self):
        self.image_path = filedialog.askopenfilename(initialdir="./", title="选择图片",
                                                     filetypes=(("JPEG files", "*.jpeg"), ("PNG files", "*.png")))

        if hasattr(self, 'image_path'):
            image = Image.open(self.image_path)
            image = image.resize(self.image_size)
            photo = ImageTk.PhotoImage(image)
            self.label_image.configure(image=photo)
            self.label_image.image = photo

            self.label_path.configure(text="图片路径：" + self.image_path)
        else:
            # 使用替代图片
            placeholder_image = Image.open('test.png')
            placeholder_image = placeholder_image.resize(self.image_size)
            placeholder_photo = ImageTk.PhotoImage(placeholder_image)
            self.label_image.configure(image=placeholder_photo)
            self.label_image.image = placeholder_photo
            self.label_path.configure(text="图片路径：")

    def predict_image(self):
        if hasattr(self, 'image_path'):
            image = Image.open(self.image_path)
            image_tensor = self.transform(image).unsqueeze_(0).to(self.device)

            with torch.no_grad():
                output = self.model(image_tensor)
                _, predicted = torch.max(output, 1)

            predicted_class = predicted.item()
            classes = ['白内障', '正常', '术后']
            predicted_label = classes[predicted_class]

            self.label_result.configure(text="预测结果：" + predicted_label)
        else:
            self.label_result.configure(text="请先上传图片！")

if __name__ == "__main__":
    window = tk.Tk()
    window.geometry("1120x640")
    app = ImageClassifierApp(window)
    window.mainloop()
