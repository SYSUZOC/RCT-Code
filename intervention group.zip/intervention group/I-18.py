import tensorflow as tf
from tensorflow.keras.applications import InceptionV3
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# 设置 GPU 显存按需分配
config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
session = tf.compat.v1.Session(config=config)

# 设置在第二个 GPU 上执行任务
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

# 定义图像尺寸和类别数
img_size = (299, 299) 
num_classes = 3 

# 加载 InceptionV3 模型，不包括顶层（全连接层）
base_model = InceptionV3(weights='imagenet', include_top=False, input_shape=(img_size[0], img_size[1], 3))

# 冻结预训练模型的权重
for layer in base_model.layers:
    layer.trainable = False

# 在顶部添加自定义分类层
model = Sequential([
    base_model,
    Flatten(),
    Dense(256, activation='relu'),
    Dropout(0.5),
    Dense(num_classes, activation='softmax')
])

# 编译模型
model.compile(optimizer=Adam(learning_rate=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])

# 数据增强
train_datagen = ImageDataGenerator(rescale=1./255,
                                   shear_range=0.2,
                                   zoom_range=0.2,
                                   horizontal_flip=True)

test_datagen = ImageDataGenerator(rescale=1./255)

# 指定训练和验证数据集路径
train_dir = 'train'
validation_dir = 'validation'

# 通过ImageDataGenerator从目录中读取图像并进行实时数据增强
train_generator = train_datagen.flow_from_directory(train_dir,
                                                    target_size=img_size,
                                                    batch_size=32,
                                                    class_mode='categorical')

validation_generator = test_datagen.flow_from_directory(validation_dir,
                                                        target_size=img_size,
                                                        batch_size=32,
                                                        class_mode='categorical')

# 训练模型
model.fit(train_generator,
          steps_per_epoch=train_generator.samples // 32,
          epochs=10,
          validation_data=validation_generator,
          validation_steps=validation_generator.samples // 32)

# 保存模型
model.save('inceptionv3_model.h5')
