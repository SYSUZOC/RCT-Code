import os
import random

# 定义数据集根目录和输出文件路径
root_dir = "tester01"
train_file = "train_dataset.txt"
test_file = "test_dataset.txt"

# 获取所有子文件夹和对应的类别名
folders = sorted(os.listdir(root_dir))

# 创建训练集和测试集列表
train_data = []
test_data = []

# 遍历每个子文件夹
for label, folder in enumerate(folders):
    folder_path = os.path.join(root_dir, folder)
    if not os.path.isdir(folder_path):
        continue

    # 获取当前类别的所有图像文件
    images = os.listdir(folder_path)

    # 随机打乱图像文件列表
    random.shuffle(images)

    # 计算划分训练集和测试集的索引
    split_index = int(0.8 * len(images))

    # 划分训练集和测试集
    train_images = images[:split_index]
    test_images = images[split_index:]

    # 将训练集图像路径和类别标签添加到训练集列表
    train_data.extend([(os.path.join(folder, image), label) for image in train_images])

    # 将测试集图像路径和类别标签添加到测试集列表
    test_data.extend([(os.path.join(folder, image), label) for image in test_images])

# 将训练集写入到输出文件
with open(train_file, "w") as f:
    for image_path, label in train_data:
        f.write(image_path + " " + str(label) + "\n")

# 将测试集写入到输出文件
with open(test_file, "w") as f:
    for image_path, label in test_data:
        f.write(image_path + " " + str(label) + "\n")
