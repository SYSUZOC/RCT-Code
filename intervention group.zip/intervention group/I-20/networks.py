import torch
import torch.nn as nn
from efficientnet_pytorch import EfficientNet

class ModifiedEfficientNet(nn.Module):
    def __init__(self, num_classes):
        super(ModifiedEfficientNet, self).__init__()
        self.backbone = EfficientNet.from_pretrained('efficientnet-b3')
        self.backbone._fc = nn.Linear(self.backbone._fc.in_features, num_classes)

    def forward(self, x):
        x = self.backbone(x)
        return x


