import os
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import Compose, ToTensor, Normalize, Resize, RandomCrop, RandomHorizontalFlip


class CustomDataset(Dataset):
    def __init__(self, folder_path, mode):
        self.folder_path = folder_path
        self.mode = mode
        self.data = self._load_data()
        self.transform = self._get_transform()

        # 打印数据集信息
        print(f"{self.mode} dataset size: {len(self)}")

    def _load_data(self):
        data = []
        file_path = "train_dataset.txt" if self.mode == "train" else "test_dataset.txt"
        with open(file_path, "r") as f:
            lines = f.readlines()
            for line in lines:
                image_path, label = line.strip().split(" ")
                data.append((image_path, int(label)))
        return data

    def _get_transform(self):
        if self.mode == "train":
            transform = Compose([
                Resize(256),
                RandomCrop(224),
                RandomHorizontalFlip(),
                ToTensor(),
                Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
        else:
            transform = Compose([
                Resize(224),
                RandomCrop(224),
                ToTensor(),
                Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
        return transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        image_path, label = self.data[index]
        image = Image.open(os.path.join(self.folder_path, image_path)).convert("RGB")

        if self.transform is not None:
            image = self.transform(image)

        return image, label


train_dataset = CustomDataset("tester01", mode="train")
test_dataset = CustomDataset("tester01", mode="test")
