from keras_preprocessing.image import ImageDataGenerator
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
data_dir = "C:\\Users\\Liang\\Desktop\\rgzn\\datanew"
train_data_dir = data_dir + "\\train"
validation_data_dir = data_dir + "\\val"
test_data_dir = data_dir + "\\test"
image_size = (128, 128)
batch_size = 32
class_names = ["cataract", "normal", "surgery"]

# 定义ImageDataGenerator进行数据预处理
datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    validation_split=0.2  
)

train_generator = datagen.flow_from_directory(
    train_data_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',

)

validation_generator = datagen.flow_from_directory(
    validation_data_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',

)

test_generator = datagen.flow_from_directory(
    test_data_dir,
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False  
)



# 构建CNN模型
model = Sequential()
model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(image_size[0], image_size[1], 3)))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(64, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Conv2D(128, (3, 3), activation='relu'))
model.add(MaxPooling2D((2, 2)))
model.add(Flatten())
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(3, activation='softmax')) 

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# 训练模型
epochs = 10
train_steps = len(train_generator)
validation_steps = len(validation_generator)
model.fit(train_generator, steps_per_epoch=train_steps, epochs=epochs, validation_data=validation_generator, validation_steps=validation_steps)

# 保存模型
model.save("6_cataract_detection_model.h5")



import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.python.keras.models import load_model
from keras_preprocessing.image import ImageDataGenerator

# 验证数据的路径
validation_data_dir = "C:\\Users\\Liang\\Desktop\\rgzn\\data\\val"
class_names = ["cataract", "normal", "surgery"]

# 定义ImageDataGenerator进行数据预处理
validation_datagen = ImageDataGenerator(rescale=1./255)

# 使用ImageDataGenerator创建验证数据生成器
validation_generator = validation_datagen.flow_from_directory(
    validation_data_dir,
    target_size=(128, 128), 
    batch_size=32,
    class_mode='categorical',
    shuffle=False  
)

# 加载模型
model = load_model('6_cataract_detection_model.h5')

# 预测
predictions = model.predict(validation_generator, steps=len(validation_generator), verbose=1)
true_labels = validation_generator.classes
predicted_labels = np.argmax(predictions, axis=1)

# 混淆矩阵
confusion = confusion_matrix(true_labels, predicted_labels)
print("Confusion Matrix:")
print(confusion)

# 输出分类报告
report = classification_report(true_labels, predicted_labels, target_names=class_names)
print("Classification Report:")
print(report)

# 可视化混淆矩阵
plt.figure(figsize=(8, 6))
sns.heatmap(confusion, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.show()
