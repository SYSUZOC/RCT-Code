import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from torch.utils.data import Dataset
from sklearn.metrics import accuracy_score, classification_report
from PIL import Image
import glob
import matplotlib.pyplot as plt

# 数据集路径和标签
data_dir = "D:/tester01"
cataract_files = glob.glob("D:/tester01/cataract/*.jpeg") + glob.glob("D:/tester01/cataract/*.jpg")
normal_files = glob.glob("D:/tester01/normal/*.jpeg") + glob.glob("D:/tester01/normal/*.jpg")
surgery_files = glob.glob("D:/tester01/surgery/*.jpeg") + glob.glob("D:/tester01/surgery/*.jpg")

cataract_labels = [0] * len(cataract_files)
normal_labels = [1] * len(normal_files)
surgery_labels = [2] * len(surgery_files)

file_paths = cataract_files + normal_files + surgery_files
labels = cataract_labels + normal_labels + surgery_labels

# 转换和加载数据
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 自定义数据集类
class CustomDataset(Dataset):
    def __init__(self, file_paths, labels, transform=None):
        self.file_paths = file_paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.file_paths)  

    def __getitem__(self, idx):
        img_path = self.file_paths[idx]
        label = self.labels[idx]

        # 使用PIL库读取图像
        image = Image.open(img_path).convert("RGB")

        if self.transform:
            image = self.transform(image)

        return image, label


# 使用修改后的 transform
dataset = CustomDataset(file_paths, labels, transform=transform)

# 计算 total_samples
total_samples = len(dataset)
print("Total files:", len(file_paths))

# 划分数据集为训练集、验证集和测试集（8:1:1）
train_size = int(0.8 * total_samples)
val_size = int(0.1 * total_samples)
test_size = total_samples - train_size - val_size

# 使用 random_split 一次进行划分
train_dataset, val_dataset, test_dataset = random_split(
    dataset, lengths=[train_size, val_size, test_size]
)

# 数据加载器
train_dataloader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_dataloader = DataLoader(val_dataset, batch_size=32, shuffle=False)
test_dataloader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# 打印数据集的长度
print("Dataset length:", len(train_dataset))


# 模型定义
class ModifiedCNN(nn.Module):
    def __init__(self, output_size):
        super(ModifiedCNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.conv4 = nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.fc1 = nn.Linear(128 * 8 * 8, 512)  # 修改全连接层节点数
        self.fc2 = nn.Linear(512, output_size)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = self.pool(F.relu(self.conv3(x)))
        x = self.pool(F.relu(self.conv4(x)))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 实例化模型、损失函数和优化器
output_size = 3  # 类别数
model = ModifiedCNN(output_size)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)

# 训练模型
num_epochs = 10
for epoch in range(num_epochs):
    model.train()
    total_loss = 0.0
    for images, labels in train_dataloader:
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        if torch.isnan(loss):
            print("训练中出现 NaN 损失！")
            continue  # 跳过这次循环
        total_loss += loss.item()
        loss.backward()
        optimizer.step()

    average_loss = total_loss / len(train_dataloader)
    if len(train_dataloader) == 0:
        average_loss = 0.0
    print(f'第 [{epoch + 1}/{num_epochs}] 轮，平均损失: {average_loss}')

    # 验证模型
    model.eval()
    val_preds, val_labels = [], []
    with torch.no_grad():
        for images, labels in val_dataloader:
            outputs = model(images)
            val_preds.extend(torch.argmax(outputs, dim=1).cpu().numpy())
            val_labels.extend(labels.cpu().numpy())

    # 计算验证集准确率
    val_accuracy = accuracy_score(val_labels, val_preds)
    if torch.isnan(torch.tensor(val_accuracy)):
        val_accuracy = 0.0

    print(f'第 [{epoch + 1}/{num_epochs}] 轮，验证准确率: {val_accuracy}')

# 在测试集上评估模型
model.eval()
test_preds, test_labels = [], []

with torch.no_grad():
    for images, labels in test_dataloader:
        outputs = model(images)
        test_preds.extend(torch.argmax(outputs, dim=1).cpu().numpy())
        test_labels.extend(labels.cpu().numpy())

# 计算测试集准确率
test_accuracy = accuracy_score(test_labels, test_preds)
if torch.isnan(torch.tensor(test_accuracy)):
    test_accuracy = 0.0

# 确保 target_names 与你的数据集中的类别数相匹配
target_names = ['cataract', 'normal', 'surgery']

# 打印测试集上的分类报告
print(classification_report(test_labels, test_preds, target_names=target_names))

# 保存模型
torch.save(model.state_dict(), 'model.pth')
print("Total samples:", total_samples)
print("Train size:", train_size)
print("Validation size:", val_size)
print("Test size:", test_size)
print(f'Test Accuracy: {test_accuracy}')
