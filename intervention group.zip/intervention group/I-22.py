#导入相应的库
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.callbacks import ModelCheckpoint
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np  
import itertools
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

#设置图片的高和宽，一次训练所选取的样本数，迭代次数
im_height = 224
im_width = 224
batch_size = 128
epochs = 50

train_dir = "train" #训练集路径
validation_dir = "validation" #验证集路径

# 定义训练集图像生成器，并进行图像增强
train_image_generator = ImageDataGenerator( rescale=1./255, # 归一化
                                            rotation_range=40, #旋转范围
                                            width_shift_range=0.2, #水平平移范围
                                            height_shift_range=0.2, #垂直平移范围
                                           shear_range=0.2, #剪切变换的程度
                                            zoom_range=0.2, #剪切变换的程度
                                            horizontal_flip=True,  #水平翻转
                                            fill_mode='nearest')
                                            
# 使用图像生成器从文件夹train_dir中读取样本，对标签进行one-hot编码
train_data_gen = train_image_generator.flow_from_directory(directory=train_dir, #从训练集路径读取图片
                                                           batch_size=batch_size, #一次训练所选取的样本数
                                                           shuffle=True, #打乱标签
                                                           target_size=(im_height, im_width), #图片resize到224x224大小
                                                           class_mode='categorical') #one-hot编码
                                                           
# 训练集样本数        
total_train = train_data_gen.n

# 定义验证集图像生成器，并对图像进行预处理
validation_image_generator = ImageDataGenerator(rescale=1./255) # 归一化

# 使用图像生成器从验证集validation_dir中读取样本
val_data_gen = validation_image_generator.flow_from_directory(directory=validation_dir,#从验证集路径读取图片
                                                              batch_size=batch_size, #一次训练所选取的样本数
                                                              shuffle=False,  #不打乱标签
                                                              target_size=(im_height, im_width), #图片resize到224x224大小
                                                              class_mode='categorical') #one-hot编码
                                                              
# 验证集样本数      
total_val = val_data_gen.n

#使用efficientnet.tfkeras的EfficientNetB0网络，并且使用官方的预训练模型
covn_base = EfficientNetB0(weights='imagenet', include_top=False ,input_shape=[im_height,im_width,3])
covn_base.trainable = True
    
#构建模型  
model = tf.keras.Sequential([
        covn_base,
        tf.keras.layers.GlobalAveragePooling2D(), #加入全局平均池化层
        tf.keras.layers.Dense(3, activation='softmax') #添加输出层(3分类)
    ])
    
#打印每层参数信息 
model.summary()  

#编译模型
model.compile(
    optimizer=tf.keras.optimizers.Adam(), #使用adam优化器
    loss = 'categorical_crossentropy', #交叉熵损失函数
    metrics=['accuracy'] #评价函数
)

def lrfn(epoch):
    LR_START = 0.00001 #初始学习率
    LR_MAX = 0.0004 #最大学习率
    LR_MIN = 0.00001 #学习率下限
    LR_RAMPUP_EPOCHS = 15 #上升过程为5个epoch
    LR_SUSTAIN_EPOCHS = 5 #学习率保持不变的epoch数
    LR_EXP_DECAY = .8 #指数衰减因子
    
    if epoch < LR_RAMPUP_EPOCHS: #第0-第5个epoch学习率线性增加
        lr = (LR_MAX - LR_START) / LR_RAMPUP_EPOCHS * epoch + LR_START
    elif epoch < LR_RAMPUP_EPOCHS + LR_SUSTAIN_EPOCHS: #不维持
        lr = LR_MAX
    else: #第6-第15个epoch学习率指数下降
        lr = (LR_MAX - LR_MIN) * LR_EXP_DECAY**(epoch - LR_RAMPUP_EPOCHS - LR_SUSTAIN_EPOCHS) + LR_MIN
    return lr

# #绘制学习率曲线
# rng = [i for i in range(epochs)]
# y = [lrfn(x) for x in rng]
# plt.plot(rng, y)
#print("Learning rate schedule: {:.3g} to {:.3g} to {:.3g}".format(y[0], max(y), y[-1]))

#使用tensorflow中的回调函数LearningRateScheduler设置学习率
lr_schedule = tf.keras.callbacks.LearningRateScheduler(lrfn, verbose=1)

#保存最优模型
checkpoint = ModelCheckpoint(
                                filepath='./logs/myefficientnet.h5', #保存模型的路径
                                monitor='val_accuracy',  #需要监视的值
                                save_weights_only=False, #若设置为True，则只保存模型权重，否则将保存整个模型（包括模型结构，配置信息等）
                                save_best_only=True, #当设置为True时，监测值有改进时才会保存当前的模型
                                mode='auto',  #当监测值为val_acc时，模式应为max，当监测值为val_loss时，模式应为min，在auto模式下，评价准则由被监测值的名字自动推断
                                period=1 #CheckPoint之间的间隔的epoch数
                            )

#开始训练
history = model.fit(x=train_data_gen,   #输入训练集
                    steps_per_epoch=total_train // batch_size, #一个epoch包含的训练步数
                    epochs=epochs, #训练模型迭代次数
                    validation_data=val_data_gen,  #输入验证集
                    validation_steps=total_val // batch_size, #一个epoch包含的训练步数
                    callbacks=[checkpoint, lr_schedule]) #执行回调函数

#保存训练好的模型
model.save('myefficientnet.h5',save_format='h5')