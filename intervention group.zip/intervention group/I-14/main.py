import os, glob
import csv

class_to_num = {}
class_name_list = os.listdir("mydata")
#print(class_name_list)

for class_name in class_name_list:
    class_to_num[class_name] = len(class_to_num.keys())
    print(class_to_num) #{'cataract': 0}{'cataract': 0, 'normal': 1}{'cataract': 0, 'normal': 1, 'surgery': 2}

image_dir = []
for class_name in class_name_list:
    image_dir += glob.glob(os.path.join("mydata", class_name, '*.jpeg'))
    print(image_dir)

import random
random.shuffle(image_dir)

with open('myself_data.csv', mode = 'w', newline = '') as f:
    writer = csv.writer(f)
    for image in image_dir:
        class_name = image.split(os.sep)[-2]
        lable = class_to_num[class_name]
        writer.writerow([image, lable])

print('write finish')

