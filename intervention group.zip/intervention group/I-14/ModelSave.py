import torch
import MyModel  
from MyModel import mymodel
# 创建并训练模型
model = mymodel([3, 128, 128])
# 保存模型的状态字典
torch.save(model.state_dict(), 'D:/AIpractice/python/My_Model1.pth')
