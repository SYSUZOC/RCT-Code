import torch
from torch import optim
from torch.nn import CrossEntropyLoss
from torch.utils.data import DataLoader

from MakeDataset import makedataset
from MyModel import mymodel
train_db = makedataset('myself_data.csv', 128, mode='train')
val_db = makedataset('myself_data.csv', 128, mode='val')
test_db = makedataset('myself_data.csv', 128, mode='test')
train_loader = DataLoader(train_db, batch_size=4, shuffle=True)
val_loader = DataLoader(val_db, batch_size=len(val_db))
test_loader = DataLoader(test_db, batch_size=len(test_db))
print('num_train:', len(train_loader.dataset))
print("num_val:", len(val_loader.dataset))
print('num_test:', len(test_loader.dataset))


def computer_acc(model, loader):
    model.eval()
    correct = 0
    total = len(loader.dataset)
    for x, y in loader:
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
        correct += torch.eq(pred, y).sum().float().item()
    return correct / total

model = mymodel([3, 128, 128])
optimizer = optim.Adam(model.parameters(), lr=1e-3)
loss_f = CrossEntropyLoss()

def train():
    best_val_acc, best_epoch = 0, 0
    for epoch in range(20):
        for inputs, targets in train_loader:
            outputs = model(inputs)
            print("Model output:", outputs)
            print("Target labels:", targets)
            for x, y in train_loader:
                model.train()
                pred = model(x)
                loss = loss_f(pred, y)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            val_acc = computer_acc(model, val_loader)
            print('Epoch:', epoch, 'Loss:', loss, 'val_acc:', val_acc)
            if val_acc > best_val_acc:
                torch.save(model.state_dict(), 'weightsMyModel.pth')
                best_val_acc = val_acc
                best_epoch = epoch
        print('Best_val_acc:', best_val_acc, 'Best_epoch:', best_epoch)

model.eval()
def test():
    model.load_state_dict(torch.load('weightsMyModel.pth'))
    print('Test_acc:', computer_acc(model, test_loader))

train()
test()