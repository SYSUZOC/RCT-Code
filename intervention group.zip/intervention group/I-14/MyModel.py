import torch
import torch.nn as nn
from einops.layers.torch import Rearrange

class mymodel(nn.Module):
    def __init__(self, image_shape):
        super(mymodel, self).__init__()
        s = image_shape
        self.Down_sample = nn.MaxPool2d(kernel_size=2, stride=2)
        self.Active_f = nn.ReLU()

        self.Conv1 = nn.Conv2d(3, 16, 3, 1, padding=1)
        self.BN1 = nn.BatchNorm2d(16)

        self.Conv2 = nn.Conv2d(16, 16, 3, 1, padding=1)
        self.BN2 = nn.BatchNorm2d(16)

        self.FC = nn.Sequential(Rearrange('b c h w -> b(c h w)'),
                                nn.Linear(16*(s[1]//4)**2, 16),
                                nn.Dropout(0.5),
                                nn.ReLU(),

                                nn.Linear(16,3))

    def forward(self, input):
        x = self.Active_f(self.Down_sample(self.BN1(self.Conv1(input))))
        x = self.Active_f(self.Down_sample(self.BN2(self.Conv2(x))))
        output = self.FC(x)
        return outputmodel = mymodel([3, 128, 128])
img = torch.randn(1, 3, 128, 128)
print(model(img).shape)