#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.preprocessing.image import ImageDataGenerator


# In[2]:


import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator


# In[3]:


datagen = ImageDataGenerator(rescale=1./255)  


# In[4]:


import os

base_dir =  r'C:\Users\13426\Desktop\tester01'
sub_dirs = ['train', 'validation', 'test']
categories = ['normal', 'cataract', 'surgery']

for d in sub_dirs:
    for cat in categories:
        os.makedirs(os.path.join(base_dir, d, cat), exist_ok=True)


# In[5]:


import os
import shutil
import numpy as np

source_dir =  r'C:\Users\13426\Desktop\tester01'  
base_dir =r'C:\Users\13426\Desktop\tester01'   

categories = ['normal', 'cataract', 'surgery']

for cat in categories:
    all_files = os.listdir(os.path.join(source_dir, cat))
    np.random.shuffle(all_files)
    
    train_files = all_files[:int(0.7 * len(all_files))]
    valid_files = all_files[int(0.7 * len(all_files)):int(0.9 * len(all_files))]
    test_files = all_files[int(0.9 * len(all_files)):]

    for file in train_files:
        shutil.copy(os.path.join(source_dir, cat, file), os.path.join(base_dir, 'train', cat, file))

    for file in valid_files:
        shutil.copy(os.path.join(source_dir, cat, file), os.path.join(base_dir, 'validation', cat, file))

    for file in test_files:
        shutil.copy(os.path.join(source_dir, cat, file), os.path.join(base_dir, 'test', cat, file))


# In[6]:


import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from tensorflow.keras.preprocessing.image import ImageDataGenerator


# In[7]:


datagen = ImageDataGenerator(rescale=1./255)

train_dir = os.path.join(base_dir, 'train')
validation_dir = os.path.join(base_dir, 'validation')

train_generator = datagen.flow_from_directory(
    train_dir,
    target_size=(256, 256),
    batch_size=32,
    class_mode='categorical'
)

validation_generator = datagen.flow_from_directory(
    validation_dir,
    target_size=(256, 256),
    batch_size=32,
    class_mode='categorical'
)


# In[8]:


model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(256, 256, 3)),
    MaxPooling2D(2, 2),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Conv2D(128, (3, 3), activation='relu'),
    MaxPooling2D(2, 2),
    Flatten(),
    Dense(512, activation='relu'),
    Dropout(0.5),
    Dense(3, activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# In[9]:


history = model.fit(
    train_generator,
    epochs=10,
    validation_data=validation_generator
)


# In[10]:


import os

test_dir = os.path.join(base_dir, 'test')

test_generator = datagen.flow_from_directory(
    test_dir,
    target_size=(256, 256),
    batch_size=32,
    class_mode='categorical'
)

loss, accuracy = model.evaluate(test_generator)
print("Test Loss:", loss)
print("Test Accuracy:", accuracy)



# In[11]:


import numpy as np


# In[22]:


categories = ['normal', 'cataract', 'surgery']


# In[23]:


import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix





y_pred = model.predict(test_generator)


y_pred_classes = np.argmax(y_pred, axis=1)


y_true = test_generator.classes


cm = confusion_matrix(y_true, y_pred_classes)


plt.figure(figsize=(10, 7))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=categories, yticklabels=categories)
plt.xlabel('Predicted labels')
plt.ylabel('True labels')
plt.show()


# In[27]:


y_pred_classes = np.argmax(y_pred, axis=1)
y_true = test_generator.classes


print("y_true values:", y_true)
print("\n-------------------\n")
print("y_pred_classes values:", y_pred_classes)




# In[29]:


y_pred = model.predict(test_generator)


# In[30]:


y_pred_classes = np.argmax(y_pred, axis=1)


# In[32]:


print(f"y_true shape: {y_true.shape}, dtype: {y_true.dtype}")
print(f"y_pred_classes shape: {y_pred_classes.shape}, dtype: {y_pred_classes.dtype}")


# In[41]:


for category in categories:
    num_files = len(os.listdir(os.path.join(test_dir, category)))
    print(f"Number of images in {category}: {num_files}")


# In[42]:


test_datagen = ImageDataGenerator(rescale=1./255)

test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(256, 256),
    batch_size=32,
    class_mode='categorical',
    shuffle=False 
)


# In[43]:


y_pred = model.predict(test_generator)
y_true = np.array(test_generator.classes)
y_pred_classes = np.argmax(y_pred, axis=1)


# In[45]:


print("y_true shape:", y_true.shape)
print("y_pred_classes shape:", y_pred_classes.shape)



# In[46]:


accuracy = np.mean(y_true == y_pred_classes) * 100
print(f"准确率: {accuracy:.2f}%")


# In[47]:


import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix

# 重新初始化test_generator
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(256, 256),
    batch_size=32,
    class_mode='categorical',
    shuffle=False
)

y_pred = model.predict(test_generator)
y_pred_classes = np.argmax(y_pred, axis=1)
y_true = test_generator.classes

cm = confusion_matrix(y_true, y_pred_classes)

plt.figure(figsize=(10, 7))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=categories, yticklabels=categories)
plt.xlabel('Predicted labels')
plt.ylabel('True labels')
plt.show()


# In[48]:


accuracy = np.mean(y_true == y_pred_classes) * 100
print(f"准确率: {accuracy:.2f}%")


# In[49]:


from sklearn.metrics import classification_report
print(classification_report(y_true, y_pred_classes, target_names=categories))


# In[50]:


model.save('path_to_save_the_model/my_modelAAA.keras')


# In[ ]:


import os

current_directory = os.getcwd()
model_path = os.path.join(current_directory, 'path_to_save_the_model/my_model.keras')
print(model_path)






