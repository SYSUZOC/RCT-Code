import os
import cv2
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dropout, Flatten, Dense, GlobalMaxPooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.applications.vgg16 import VGG16
from tensorflow.keras.models import Model
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# 数据集路径
TRAIN_DIR = 'D:/tester01/'

# 目标缩放尺寸
ROWS = 128
COLS = 128
CHANNELS = 3

# 类别映射
class_names = ['normal', 'cataract', 'surgery']
class_labels = {class_name: i for i, class_name in enumerate(class_names)}

def read_image(file_path):
    """读取并预处理图像"""
    img = cv2.imread(file_path, cv2.IMREAD_COLOR)  
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  
    return cv2.resize(img, (ROWS, COLS), interpolation=cv2.INTER_CUBIC)

def prep_data(image_file_names):
    """图像和标签准备函数"""
    count = len(image_file_names)
    data = np.ndarray((count, ROWS, COLS, CHANNELS), dtype=np.float32)
    labels = np.zeros((count,), dtype=int)  
    for i, image_file in enumerate(image_file_names):
        image = read_image(image_file)
        data[i] = image / 255.0  
        for class_name, class_label in class_labels.items():
            if class_name in image_file:
                labels[i] = class_label
                break
        if i % 1000 == 0:
            print(f'Processed {i} of {count}')
    return data, to_categorical(labels, num_classes=len(class_names))

# 获取所有图像文件路径
image_files = [os.path.join(dp, f) for dp, dn, filenames in os.walk(TRAIN_DIR) for f in filenames if os.path.splitext(f)[1].lower() in ['.png', '.jpg', '.jpeg']]
random.shuffle(image_files) 

# 准备数据和标签
images, labels = prep_data(image_files)

# 划分数据集
X_train, X_temp, y_train, y_temp = train_test_split(images, labels, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)
print(f"Training set size: {len(X_train)}")
print(f"Validation set size: {len(X_val)}")
print(f"Test set size: {len(X_test)}")

# 构建VGG16模型
def build_model():
    base_model = VGG16(include_top=False, weights='imagenet', input_shape=(ROWS, COLS, CHANNELS), pooling='avg')
    for layer in base_model.layers:
        layer.trainable = False  

    x = base_model.output
    x = Dense(512, activation='relu')(x)
    x = Dropout(0.5)(x)
    predictions = Dense(len(class_names), activation='softmax')(x)
    model = Model(inputs=base_model.input, outputs=predictions)
    
    model.compile(optimizer=Adam(learning_rate=1e-3), loss='categorical_crossentropy', metrics=['accuracy'])
    return model

model = build_model()

# 训练模型
model.fit(X_train, y_train, batch_size=32, epochs=10, validation_data=(X_val, y_val))

# 评估模型
scores = model.evaluate(X_test, y_test, verbose=1)
print(f'Test loss: {scores[0]}, Test accuracy: {scores[1]}')

# 绘制混淆矩阵
predictions = model.predict(X_test)
predicted_classes = np.argmax(predictions, axis=1)
true_classes = np.argmax(y_test, axis=1)
cm = confusion_matrix(true_classes, predicted_classes)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

model.save('白内障model.h5')