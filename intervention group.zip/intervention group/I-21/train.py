import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms, datasets
from torch.utils.data import DataLoader
from model import GoogLeNet
import logging
import os

# Create a 'logs' directory if it doesn't exist
log_dir = 'logs'
os.makedirs(log_dir, exist_ok=True)

# Configure logging
logging.basicConfig(filename=os.path.join(log_dir, 'train_log.txt'), level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define transforms for data preprocessing
train_transforms = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# Load your custom dataset using ImageFolder
train_dataset = datasets.ImageFolder(root='/home/Eye/tester01/train', transform=train_transforms)

# Define data loaders
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# Initialize the model
model = GoogLeNet()

# Define loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Train the model
num_epochs = 10
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for batch_idx, (inputs, labels) in enumerate(train_loader):
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item()

        # Log training information
        if batch_idx % 10 == 9:  # Print every 10 batches
            avg_loss = running_loss / 10
            logging.info(f'Epoch [{epoch+1}/{num_epochs}], Batch [{batch_idx+1}/{len(train_loader)}], Loss: {avg_loss:.4f}')
            running_loss = 0.0

# Save the trained model
torch.save(model.state_dict(), 'googlenet_model.pth')
